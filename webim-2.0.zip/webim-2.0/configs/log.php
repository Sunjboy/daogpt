<?php
$log['master'] = array(
    'type' => 'FileLog',
    'file' => dirname(__DIR__) . '/logs/webim.log',
);
return $log;