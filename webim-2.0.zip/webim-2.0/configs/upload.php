<?php
return array(
    'base_dir' => ROOT_PATH . '/resources/static/uploads/',
    'base_url' => '/static/uploads/',
);