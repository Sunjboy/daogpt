<?php
$cache['master'] = array(
    'type' => 'Redis',
);
return $cache;