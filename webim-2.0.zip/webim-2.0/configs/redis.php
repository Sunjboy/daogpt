<?php
$redis['master'] = array(
    'host' => '127.0.0.1',
);
return $redis;